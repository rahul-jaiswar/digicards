$(document).ready(function() {
    $('#auth-carousel').owlCarousel({
        loop:false,
        margin:10,
        nav:false,
        items:1
    })
});