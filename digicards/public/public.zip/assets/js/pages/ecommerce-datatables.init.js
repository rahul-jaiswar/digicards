// datatable
$(document).ready(function() {
    $('.datatable').DataTable();
    $(".dataTables_length select").addClass('form-select form-select-sm');
});