<?php namespace App\Controllers;

class Franc extends BaseController
{
	public function index()
	{
		
	}
}
