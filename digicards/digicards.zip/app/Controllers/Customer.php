<?php 
namespace App\Controllers;
use App\Models\CustomerModel;
use App\Models\CardModel;

class Customer extends BaseController
{
	private $customer = '' ;
	private $card = '' ;
	private $team = '' ;
    public function __construct(){
    	helper(['url','form']);
        $this->customer = new CustomerModel(); 
        $this->card = new CardModel(); 
        $this->template = new CardModel(); 
        $this->session = \Config\Services::session();
        $this->db = \Config\Database::connect();
    }
	public function list()
	{
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customer' => $this->customer->orderBy('cust_id', 'DESC')->findAll()
		];
		return view('customer/list', $data);
	}
	function validateemail(){
		$emailid = $this->request->getPost('emailval');
		$results = $this->customer->where('email', $emailid)->countAllResults();
		if ($results > 0) {
			return $this->response->setJSON([
	            'error' => true,
	        ]);
		} else {
			return $this->response->setJSON([
	            'error' => false,
	        ]);
		}
	}
	function validatemobile(){
		$mobile = $this->request->getPost('mobileval');
		$results = $this->customer->where('mobile_no', $mobile)->countAllResults();
		if ($results > 0) {
			return $this->response->setJSON([
	            'error' => true,
	        ]);
		} else {
			return $this->response->setJSON([
	            'error' => false,
	        ]);
		}
	}
	public function add(){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$emailotp = rand(0, 1000000);
				$UID = 'TSC'.rand(0, 10000); 
				$customer=[
					'company_code'=> $UID,
					'lead_channel'=> $this->request->getPost('lead_channel'),
					'card_category'=> $this->request->getPost('card_category'),
					'card_material'=> $this->request->getPost('card_material'),
					'firstname'=> $this->request->getPost('firstname'),
					'lastname'=> $this->request->getPost('lastname'),
					'username'=> $this->request->getPost('username'),
					'company_cat'=> $this->request->getPost('company_cat'),
					'company_name'=> $this->request->getPost('company_name'),
					'company_url'=> $this->request->getPost('company_url'),
					'email'=> $this->request->getPost('email_address'),
					'email_otp'=> $emailotp,
					'mobile_no'=> $this->request->getPost('mobile_no'),
					'password'=> md5($this->request->getPost('password')),
					'enable'=> 1,
				];
				$template=[
					'company_code'=> $UID,
					'temp_name'=> 'Default',
					'temp_cat'=> 'Business',
					'enable'=> 1
				];
				$info=[
					'company_code'=> $UID,
					'company_name'=> $this->request->getPost('company_name'),
					'card_category'=> $this->request->getPost('card_category')
				];
				if($this->customer->insert($customer)){
					$this->db->table('card_template_tb')->insert($template);
					$this->db->table('card_info_tb')->insert($info);
					$this->session->setFlashdata('msg', 'Customer Registered Successfully');
				}
				else{
					$this->session->setFlashdata('msg', 'Something went wrong');
				}
				$data = [
					'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
					'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
					'customer' => $this->customer->orderBy('cust_id', 'DESC')->findAll()
				];
				return redirect()->to('Customer/list')->withInput($data);
				
            }
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible'])
		];
		return view('customer/add', $data);
	}
	public function update($id = null){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->customer->set($data)->where('company_code',$id)->update();
				$this->session->setFlashdata('msg', 'Customer Updated Successfully');
				return redirect()->to('Customer/update/'.$id);
			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'custdata' => $this->customer->where('company_code', $id)->first(),
		];
		// echo"<pre>";
		// print_r($data);
		// exit();
		return view('customer/update', $data);
	}
	public function delete($id = null){
		if($this->customer->where('company_code', $id)->delete()){
			$this->db->table('card_template_tb')->where('company_code', $id)->delete();
			$this->db->table('card_info_tb')->where('company_code', $id)->delete();
			$this->db->table('card_info_tb')->where('company_code', $id)->delete();
			$this->session->setFlashdata('msg', 'Customer Deleted Successfully');
		}
		else{
			$this->session->setFlashdata('msg', 'Something went wrong');
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customer' => $this->customer->orderBy('cust_id', 'DESC')->findAll()
		];
		return redirect()->to('Customer/list')->withInput($data);
    }
    function card(){
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'cardlist' => $this->card->orderBy('card_id', 'DESC')->findAll()
		];
		// echo"<pre>";
		// print_r($data);
		// exit();
		return view('customer/card', $data);
	}
	function insertCategory(){
		$data = $this->request->getVar();
		$this->db->table('team_cat_tb')->insert($data);
		$this->session->setFlashdata('msg', 'Team Category Added successfully');
		return redirect()->to('Customer/team');
	}
	function insertDesignation(){
		$data = $this->request->getVar();
		$this->db->table('team_designation_tb')->insert($data);
		$this->session->setFlashdata('msg', 'Designation Category Added successfully');
		return redirect()->to('Customer/team');
	}
	function team($id =null){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customerlist' => $this->customer->orderBy('cust_id', 'DESC')->findAll(),
			'designationlist' => $this->db->table('team_designation_tb')->get()->getResult(),
			'teamnamelist' => $this->db->table('team_cat_tb')->get()->getResult(),
		];
		return view('card/team', $data);
	}
	function social(){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->db->table('social_channel_tb')->insert($data);
				$this->session->setFlashdata('msg', 'Channel Category Added successfully');
				return redirect()->to('Customer/social');
			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'socialchannellist' => $this->db->table('social_channel_tb')->get()->getResult(),
		];
		return view('card/social', $data);
	}
	function product(){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->db->table('product_category_tb')->insert($data);
				$this->session->setFlashdata('msg', 'Product Category Added successfully');
				return redirect()->to('Customer/product');
			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customerlist' => $this->customer->orderBy('cust_id', 'DESC')->findAll(),
			'productcategorylist' => $this->db->table('product_category_tb')->get()->getResult(),
		];
		return view('card/product', $data);
	}
	function insertServiceCat(){
		
	}
	function service($id =null){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->db->table('service_category_tb')->insert($data);
				$this->session->setFlashdata('msg', 'Service Category Added successfully');
				return redirect()->to('Customer/service');
			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customerlist' => $this->customer->orderBy('cust_id', 'DESC')->findAll(),
			'servicecatlist' => $this->db->table('service_category_tb')->get()->getResult(),
		];
		return view('card/service', $data);
	}
	function catalogue(){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->db->table('catalogue_category_tb')->insert($data);
				$this->session->setFlashdata('msg', 'Catalogue Category Added successfully');
				return redirect()->to('Customer/catalogue');
			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customerlist' => $this->customer->orderBy('cust_id', 'DESC')->findAll(),
			'cataloguecatlist' => $this->db->table('catalogue_category_tb')->get()->getResult()
		];
		return view('card/catalogue', $data);
	}
	function gallery($id =null){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

			}
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'cardlist' => $this->card->orderBy('card_id', 'DESC')->findAll()
		];
		return view('card/gallery', $data);
	}
	function payments($id =null){
		try {
			if ($_SERVER['REQUEST_METHOD'] == 'POST'){
				$data = $this->request->getVar();
				$this->db->table('pay_channel_tb')->insert($data);
				$this->session->setFlashdata('msg', 'Payment Channel Category Added successfully');
				return redirect()->to('Customer/payments');
			}	
		} catch (Exception $e) {
			
		}
		$data = [
			'title_meta' => view('partials/title-meta', ['title' => 'Dashboard']),
			'page_title' => view('partials/page-title', ['title' => 'Dashboard', 'pagetitle' => 'Minible']),
			'customerlist' => $this->customer->orderBy('cust_id', 'DESC')->findAll(),
			'paymentcatlist' => $this->db->table('pay_channel_tb')->get()->getResult()
		];
		return view('card/payments', $data);
	}
	
}