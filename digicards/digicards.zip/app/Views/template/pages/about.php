<!doctype html>
<html lang="en">
<head>
    <?= $this->include('template/partials/head-css') ?>
    <style type="text/css">
    </style>
</head>
<body class="" style="position: relative; width: 360px;margin: auto;">
    
    <?= $this->include('template/pages/nav') ?>
    <?= $this->include('template/partials/vendor-scripts') ?>
</body>

</html>