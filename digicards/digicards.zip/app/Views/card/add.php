<!doctype html>
<html lang="en">
<head>
    <?= $title_meta ?>
    <?= $this->include('partials/head-css') ?>
    <?= $this->include('partials/css/datatable') ?>
    <?= $this->include('partials/css/pdfreader') ?>
</head>
<?= $this->include('partials/body') ?>
<!-- Begin page -->
<div id="layout-wrapper">
    <?= $this->include('partials/menu') ?>
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                    	<?= \Config\Services::validation()->listErrors();
		                $message = \Config\Services::session()->getFlashdata('msg');
		                //echo"<pre>";print_r(isset($message));exit();?>
		                <?php if (isset($message)) : ?>
		                <div class="alert alert-secondary alert-dismissible fade show" role="alert">
		                    <?= \Config\Services::session()->getFlashdata('msg'); ?>
		                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
		                    </button>
		                </div>
		                <?php endif; ?>
                    	<div class="row">
	                        <div class="col-xl-12">
	                            <div class="card">
	                                <div class="card-body">
	                                    <h4 class="card-title">Udpate Card Details </h4>
	                                    <p class="card-title-desc">Note: (*) Mark Feild are Mandatory</p>
	                                    <!-- Nav tabs -->
	                                    <?php $activetab = \Config\Services::session()->get('activetab');
	                                    // echo"<pre>";
	                                    // print_r($activetab);
	                                    // exit();?>
	                                    <ul class="nav nav-pills nav-justified bg-light" role="tablist">
	                                        <li class="nav-item">
	                                            <a class="nav-link  <?= strcmp($activetab, "") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-preview"
	                                                role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-postcard"></i></span>
	                                                <span class="d-none d-sm-block">Preview</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "info") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-info" role="tab">
	                                                <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
	                                                <span class="d-none d-sm-block">Info</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "team") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-team" role="tab">
	                                                <span class="d-block d-sm-none"><i class="fas fa-users"></i></span>
	                                                <span class="d-none d-sm-block">Team</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "social") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-social" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-facebook"></i></span>
	                                                <span class="d-none d-sm-block">Social Media</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "product") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-product" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-box"></i></span>
	                                                <span class="d-none d-sm-block">Product</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "service") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-service" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-store"></i></span>
	                                                <span class="d-none d-sm-block">Service</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "catalogue") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-catalogue" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-book"></i></span>
	                                                <span class="d-none d-sm-block">Catalogue</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "gallery") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-gallery" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-images"></i></span>
	                                                <span class="d-none d-sm-block">Gallery</span>
	                                            </a>
	                                        </li>
	                                        <li class="nav-item">
	                                            <a class="nav-link <?= strcmp($activetab, "payment") == 0 ? "active" : ""  ?>" data-bs-toggle="tab" href="#nav-payments" role="tab">
	                                                <span class="d-block d-sm-none"><i class="uil-wallet"></i></span>
	                                                <span class="d-none d-sm-block">Payments</span>
	                                            </a>
	                                        </li>
	                                    </ul>
	                                    <!-- Tab panes -->
	                                    <div class="tab-content text-muted">
	                                    	<!-- Card Preview Start -->
	                                        <div class="tab-pane <?= strcmp($activetab, "") == 0 ? "active" : ""  ?>"  id="nav-preview" role="tabpanel">
	                                        	<div class="row mt-4">
								                    <div class="col-xl-7">
								                        <div class="card">
								                            <div class="card-body">
								                                <div class="d-flex align-items-start">
								                                    <div class="ms-3 me-4">
								                                        <h1 class="display-4 mb-0">01</h1>
								                                    </div>
								                                    <div class="flex-grow-1 align-self-center">
								                                        <p class="mb-2">Template Name</p>
								                                        <h5 class="mb-0">Mobile eCommerce HTML Template (Layout One)</h5>
								                                    </div>
								                                </div>
								                            </div>
								                        </div>
								                        <div class="card">
								                        	<div class="card-body">
								                                <div class="d-flex align-items-start">
								                                    <div class="ms-3 me-4">	
								                                        <img src="https://htmldemo.net/rick/p2/img/rick.png" alt="qr code">
								                                    </div>
								                                    <div class="flex-grow-1 align-self-center">
								                                        <h4 class="mb-2">Sharing URL</h4>
								                                        <h5 class="mb-0">
								                                        	<a href="<?php echo $card_url.''.$customer['company_url']; ?>" target="_blank">
								                                        		<span class="badge bg-primary"><?php echo $card_url.''.$customer['company_url'];?></span>
								                                        	</a>
								                                    	</h5>
								                                        <h4 class="mt-2">Check Meta Tags of Social Media</h4>
								                                        <div class="btn-group" role="group" aria-label="Basic example">
				                                                        <a class="btn btn-outline-secondary"><i class="bx bxl-facebook-circle"></i></a>
				                                                        <button type="button" class="btn btn-outline-secondary"><i class="bx bxl-instagram-alt"></i></button>
				                                                        <button type="button" class="btn btn-outline-secondary"><i class="bx bxl-whatsapp-square"></i></button>
				                                                    </div>
								                                    </div>
								                                </div>
								                            </div>
								                        </div>
								                        <div class="card">
								                            <div class="card-body">
								                                <div class="d-flex align-items-start">
								                                    <div class="flex-grow-1 align-self-center">
								                                        <p class="mb-2">Font Family</p>
								                                        <h5 class="mb-0">"IBM Plex Sans", sans-serif</h5>
								                                    </div>
								                                </div>
								                            </div>
								                        </div>
								                    </div>
								                    <div class="col-xl-5">
								                    	<iframe src="<?php echo $card_url.''.$customer['company_url'];?>" style="height: 100%;width: 100%;"></iframe>
								                    </div>
								                </div>
	                                        </div>
	                                        <!-- Card Preview End -->
	                                        <div class="tab-pane <?= strcmp($activetab, "info") == 0 ? "active" : ""  ?>" id="nav-info" role="tabpanel">
	                                        	<form class="custom-validation" action="<?=site_url('Card/info/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr> General Info <hr></h4>
                                                    <div class="row">
                                                    	<div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name" value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Category</label>
                                                            <select class="form-select form-control" name="company_cat" id="company_cat" required>
                                                                <option value="<?php echo $customer['company_cat']?>"><?php echo $customer['company_cat']?></option>
                                                                <option>Choose or Company Category</option>
                                                                <option value="Companies Limited by Shares">Companies Limited by Shares</option>
                                                                <option value="Companies Limited by Guarantee">Companies Limited by Guarantee</option>
                                                                <option value="Unlimited Companies">Unlimited Companies</option>
                                                                <option value="One Person Companies (OPC)">One Person Companies (OPC)</option>
                                                                <option value="Private Companies">Private Companies</option>
                                                                <option value="Public Companies">Public Companies</option>
                                                                <option value="Holding and Subsidiary Companies">Holding and Subsidiary Companies</option>
                                                                <option value="Associate Companies">Associate Companies</option>
                                                                <option value="Companies in terms of Access to Capital">Companies in terms of Access to Capital</option>
                                                                <option value="Government Companies">Government Companies</option>
                                                                <option value="Foreign Companies">Freign Companies</option>
                                                                <option value="Charitable Companies">Charitable Companies</option>
                                                                <option value="Dormant Companies">Dormant Companies</option>
                                                                <option value="Nidhi Companies">Nidhi Companies</option>
                                                                <option value="Public Financial Institutions">Public Financial Institutions</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Est Date</label>
                                                            <?php if(!empty($card['est_date'])){?>
                                                            	<input type="date" class="form-control" name="est_date" id="est_date" value="<?php echo date('Y-m-d', strtotime($card['est_date'])) ?>" />
                                                            <?php }else{?>
                                                            	<input type="date" class="form-control" name="est_date" id="est_date" />
                                                            <?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company PAN NO</label>
                                                            <?php if(!empty($card['PAN_no'])){?>
                                                            	<input type="text" class="form-control" name="PAN_no" id="PAN_no" value="<?php echo $card['PAN_no']?>"  />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="PAN_no" id="PAN_no"  />
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company STN NO</label>
                                                            <?php if(!empty($card['STN_no'])){?>
                                                            	<input type="text" class="form-control"name="STN_no" id="STN_no" value="<?php echo $card['STN_no']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control"name="STN_no" id="STN_no" />
                                                           	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company GST NO</label>
                                                            <?php if(!empty($card['GST_no'])){?>
                                                            	<input type="text" class="form-control" name="GST_no" id="GST_no" value="<?php echo $card['GST_no']?>"  />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="GST_no" id="GST_no"   />
                                                           	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Trademark</label>
                                                            <?php if(!empty($card['cust_copyright'])){?>
                                                            	<input type="text" class="form-control" name="cust_copyright" id="cust_copyright" value="<?php echo $card['cust_copyright']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="cust_copyright" id="cust_copyright"/>
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Email</label>
                                                            <?php if(!empty($card['company_email'])){?>
                                                            	<input type="email" class="form-control" name="company_email" id="" value="<?php echo $card['company_email']?>" />
                                                           	<?php }else{?>
                                                           		<input type="email" class="form-control" name="company_email" id="" />
                                                           	<?php }?>
                                                           
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Support Email</label>
                                                            <?php if(!empty($card['support_email'])){?>
                                                            	<input type="email" class="form-control" name="support_email" id="" value="<?php echo $card['support_email']?>" />
                                                           	<?php }else{?>
                                                           		<input type="email" class="form-control" name="support_email" id="" />
                                                           	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Support Contact</label>
                                                            <?php if(!empty($card['sup_contact_no'])){?>
                                                            	<input type="number" class="form-control" name="sup_contact_no" id="" value="<?php echo $card['sup_contact_no']?>" />
                                                           	<?php }else{?>
                                                           		<input type="number" class="form-control" name="sup_contact_no" id="" />
                                                           	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Whastapp Business</label>
                                                            <?php if(!empty($card['whatsapp_business'])){?>
                                                            	<input type="number" class="form-control" name="whatsapp_business" id="" value="<?php echo $card['whatsapp_business']?>" />
                                                           	<?php }else{?>
                                                           		<input type="number" class="form-control" name="whatsapp_business" id=""/>
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Website URL</label>
                                                            <?php if(!empty($card['website_url'])){?>
                                                            	<input type="text" class="form-control" name="website_url" id="" value="<?php echo $card['website_url']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="website_url" id="" />
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Map Link</label>
                                                            <?php if(!empty($card['company_map_link'])){?>
                                                            	<input type="text" class="form-control" name="company_map_link" id="" value="<?php echo $card['company_map_link']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="company_map_link" id="" />
                                                           	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Intro Video URL</label>
                                                            <?php if(!empty($card['intro_video'])){?>
                                                            	<input type="text" class="form-control" name="intro_video" id="" value="<?php echo $card['intro_video']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="intro_video" id="" />
                                                           	<?php }?>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="row">
                                                        <div class="col-xl-12 mb-3">
                                                            <label class="form-label">About the Company</label>
                                                            <?php if(!empty($card['about_us'])){?>
                                                            	<textarea class="form-control" placeholder="Write about Company...." name="about_us" id=""><?php echo $card['about_us']?></textarea>
                                                           	<?php }else{?>
                                                           		<textarea class="form-control" placeholder="Write about Company...." name="about_us" id=""></textarea>
                                                           	<?php }?>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Country</label>
                                                            <?php if(!empty($card['country'])){?>
                                                            	<input type="text" class="form-control" name="country" id="country" value="<?php echo $card['country']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="country" id="country"/>
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">State</label>
                                                            <?php if(!empty($card['state'])){?>
                                                            	<input type="text" class="form-control" name="state" id="state" value="<?php echo $card['state']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="state" id="state" />
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">City</label>
                                                            <?php if(!empty($card['city'])){?>
                                                            	<input type="text" class="form-control" name="city" id="city" value="<?php echo $card['city']?>"/>
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="city" id="city" />
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Pincode</label>
                                                            <?php if(!empty($card['pincode'])){?>
                                                            	<input type="text" class="form-control" name="pincode" id="pincode" value="<?php echo $card['pincode']?>" />
                                                           	<?php }else{?>
                                                           		<input type="text" class="form-control" name="pincode" id="pincode" />
                                                           	<?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-12 mb-3">
                                                            <label class="form-label">Company Address</label>
                                                            <?php if(!empty($card['address'])){?>
                                                            	<textarea class="form-control" placeholder="Enter Full Address" name="address" id="address"><?php echo $card['address']?></textarea>
                                                           	<?php }else{?>
                                                           		<textarea class="form-control" placeholder="Enter Full Address" name="address" id="address"></textarea>
                                                           	<?php }?>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                    	<div class="col-md-4">
                                                    		<label>Upload Company Logo/ Card Holder Profile</label>
                                                    		<div style="background-color: blue;padding: 5px;">
																<label class="newbtn" style="cursor: pointer;">
																    <img id="blah" src="http://placehold.it/120x120" style="max-width:100px;height:100px;">
																    <input id="pic" class='pis' onchange="uploadcompanylogo(this);" type="file" style="display: none;">
																</label>
																<label class="uploadprofile" style="cursor: pointer;">
																    <img id="profilehere" src="http://placehold.it/120x120" style="max-width:100px;height:100px;">
																    <input id="profile" class='pis' onchange="uploadprofile(this);" type="file" style="display: none;">
																</label>
															</div>
                                                    	</div>
                                                    	<div class="col-md-4">
                                                    		<label class="form-label">Upload Company Profile PDF</label>
                                                    		<div id="preview-container">
															    <img src="http://placehold.it/120x120" id="upload-dialog">
															    <input type="file" id="pdf-file" name="pdf" accept="application/pdf" />
															    <div id="pdf-loader">Loading Preview ..</div>
															    <canvas id="pdf-preview" width="150"></canvas>
															    <div class="row">
															        <span id="pdf-name"></span>
															    </div>
															    <div class="row">
															        <button class="" id="cancel-pdf">Cancel</button>
															        <button class="" id="cancel-pdf">Cancel</button>
															    </div>
															</div>
                                                    	</div>
                                                    	<div class="col-md-4">
                                                    		<label class="form-label">Upload Company Catalogue PDF</label>
                                                    		<div id="preview-container">
															    <img src="http://placehold.it/120x120" id="upload-dialog">
															    <input type="file" id="pdf-file" name="pdf" accept="application/pdf" />
															    <div id="pdf-loader">Loading Preview ..</div>
															    <canvas id="pdf-preview" width="150"></canvas>
															    <div class="row">
															        <span id="pdf-name"></span>
															    </div>
															    <div class="row">
															        <button class="" id="cancel-pdf">Cancel</button>
															    </div>
															</div>
                                                    	</div>
                                                    </div>
                                                    <div>
                                                        <div>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1">
                                                                Submit
                                                            </button>
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
	                                        </div>
	                                        <!-- Card Information -->
	                                        <!-- Card Team -->
	                                        <div class="tab-pane <?= strcmp($activetab, "team") == 0 ? "active" : ""  ?>" id="nav-team" role="tabpanel">
	                                            <form class="custom-validation" action="<?=site_url('Card/team/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr> Team Member Info <hr></h4>
                                                    <div class="row">
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Enter Team Name</label>
                                                            <select class="form-select form-control" name="team_name" id="team_name">
                                                            	<?php if(!empty($tmember['team_name'])){?>
                                                            	<option value="<?php echo $tmember['team_name'] ?>"><?php echo $tmember['team_name'] ?></option>
	                                                            	<option value="">Enter or Select Team Name</option>
	                                                                <option value="Referral">Operations</option>
	                                                                <option value="Referral">Markeing</option>
	                                                                <option value="Referral">Tech</option>
	                                                                <option value="Referral">Sales</option>
	                                                            <?php }else{?>
	                                                            	<option selected="">Enter or Select Team Name</option>
	                                                                <option value="Referral">Operations</option>
	                                                                <option value="Referral">Markeing</option>
	                                                                <option value="Referral">Tech</option>
	                                                                <option value="Referral">Sales</option>
	                                                            <?php }?>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Enter Person Designation</label>
                                                            <select class="form-select form-control" name="designation" id="designation">
                                                            	<?php if(!empty($tmember['designation'])){?>
                                                            	<option value="<?php echo $tmember['designation'] ?>"><?php echo $tmember['designation'] ?></option>
                                                            	<option value="">Select Designation</option>
                                                                <optgroup label="Top Management">
                                                                <option value="Chairperson">Chairperson</option>
                                                                <option value="Chairperson">President</option>
                                                                <option value="Referral">CEO</option>
                                                                <option value="Referral">Executive Director</option>
                                                                <option value="Referral">Managing Director</option>
                                                                <option value="Referral">Chief Operating Officer </option>
                                                                <option value="Referral">Chief Finance Officer</option>
                                                                <option value="Referral">Vice President</option>
                                                                </optgroup>
                                                                <optgroup label="Middle Management">
                                                                <option value="Referral">General Manager</option>
                                                                <option value="Referral">Area Manager</option>
                                                                <option value="Web Commerce">Director</option>
                                                                <option value="Web Commerce">Branch Manager</option>
                                                                <option value="Web Commerce">Senior Manager</option>
                                                                </optgroup>
                                                                <optgroup label="Lower Management">
                                                                <option value="Referral">Supervisor</option>
                                                                <option value="Referral">Manager</option>
                                                                <option value="Referral">Assistant Manager</option>
                                                                <option value="VP">Section Head</option>
                                                                <option value="Manager">Team Lead</option>
                                                                <option value="Executive">Executive</option>
                                                                </optgroup>
	                                                            <?php }else{?>	
                                                            	<option selected="">Select Designation</option>
                                                                <optgroup label="Top Management">
                                                                <option value="Chairperson">Chairperson</option>
                                                                <option value="Chairperson">President</option>
                                                                <option value="Referral">CEO</option>
                                                                <option value="Referral">Executive Director</option>
                                                                <option value="Referral">Managing Director</option>
                                                                <option value="Referral">Chief Operating Officer </option>
                                                                <option value="Referral">Chief Finance Officer</option>
                                                                <option value="Referral">Vice President</option>
                                                                </optgroup>
                                                                <optgroup label="Middle Management">
                                                                <option value="Referral">General Manager</option>
                                                                <option value="Referral">Area Manager</option>
                                                                <option value="Web Commerce">Director</option>
                                                                <option value="Web Commerce">Branch Manager</option>
                                                                <option value="Web Commerce">Senior Manager</option>
                                                                </optgroup>
                                                                <optgroup label="Lower Management">
                                                                <option value="Referral">Supervisor</option>
                                                                <option value="Referral">Manager</option>
                                                                <option value="Referral">Assistant Manager</option>
                                                                <option value="VP">Section Head</option>
                                                                <option value="Manager">Team Lead</option>
                                                                <option value="Executive">Executive</option>
                                                                </optgroup>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Card Material</label>
                                                            <select class="form-select" name="card_category" id="card_category">
                                                            	<?php if(!empty($tmember['card_category'])){?>
                                                            		<option value="<?php echo $tmember['card_category']?>"><?php echo $tmember['card_category']?></option>
                                                            		<option value="">Select Card Material</option>
	                                                                <option value="1">Plain PVC</option>
	                                                                <option value="3">Premium PVC</option>
	                                                                <option value="4">Plain Wooden</option>
	                                                                <option value="4">Metal Premium Card (Rose GOLD)</option>
	                                                                <option value="4">Metal Premium Card (GOLD)</option>
	                                                                <option value="4">Metal Premium Card (Stainless Steel)</option>
                                                        		<?php }else{?>
                                                        			<option selected>Select Card Material</option>
	                                                                <option value="1">Plain PVC</option>
	                                                                <option value="3">Premium PVC</option>
	                                                                <option value="4">Plain Wooden</option>
	                                                                <option value="4">Metal Premium Card (Rose GOLD)</option>
	                                                                <option value="4">Metal Premium Card (GOLD)</option>
	                                                                <option value="4">Metal Premium Card (Stainless Steel)</option>
                                                        		<?php }?>
                                                                
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">User Code</label>
                                                            <?php if(!empty($tmember['userUID'])){?>
                                                            	 <input type="text" class="form-control" name="userUID" id="userUID" value="<?php echo $tmember['userUID']; ?>" readonly />
                                                            <?php }else{?>	
                                                            	 <input type="text" class="form-control" name="userUID" id="userUID" value="<?php echo "TAPT".(rand(0,10000));?>" readonly />
                                                            <?php }?>	
                                                           
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">First Name</label>
                                                            <?php if(!empty($tmember['firstname'])){?>
                                                            	<input type="text" class="form-control" required placeholder="Enter First Name" name="firstname" id="firstname" value="<?php echo $tmember['firstname']?>" />
                                                            <?php }else{?>	
                                                            	<input type="text" class="form-control" required placeholder="Enter First Name" name="firstname" id="firstname" />
                                                            <?php }?>
                                                            
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Last Name</label>
                                                            <?php if(!empty($tmember['lastname'])){?>
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="lastname" id="lastname" value="<?php echo $tmember['lastname']; ?>" />
                                                            <?php }else{?>	
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="lastname" id="lastname" />
                                                            <?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Username</label>
                                                            <div class="input-group">
                                                        	<?php if(!empty($tmember['username'])){?>
                                                        		<input type="text" class="form-control" required placeholder="Create Username" name="username" id="username" value="<?php echo $tmember['username']?>">
                                                                <div class="input-group-text">@tap-savvy.com</div>
                                                            <?php }else{?>	
                                                            	<input type="text" class="form-control" required placeholder="Create Username" name="username" id="username">
                                                                <div class="input-group-text">@tap-savvy.com</div>
                                                            <?php }?>
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Email</label>
                                                            <?php if(!empty($tmember['email'])){?>
                                                            	<input type="email" class="form-control" required placeholder="Enter Email Address" name="email" id="email" value="<?php echo $tmember['email']?>" />
                                                            <?php }else{?>	
                                                            	<input type="email" class="form-control" required placeholder="Enter Email Address" name="email" id="email" />
                                                            <span class="text-danger"><?= isset($validation) ? display_error($validation,'emailaddress') : '' ?></span>
                                                            <?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Mobile No</label>
                                                            <?php if(!empty($tmember['mobile_no'])){?>
                                                            	<input type="text" class="form-control" required placeholder="Enter Mobile No" name="mobile_no" id="mobile_no" value="<?php echo $tmember['mobile_no']?>" />
                                                            <?php }else{?>	
                                                            	<input type="text" class="form-control" required placeholder="Enter Mobile No" name="mobile_no" id="mobile_no" />
                                                            <?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Password</label>
                                                            <?php if(!empty($tmember['team_password'])){?>
                                                            	<input type="password" class="form-control" required placeholder="Create Password" name="team_password" id="team_password" value="<?php echo $tmember['team_password']?>" />
                                                            <?php }else{?>	
                                                            	<input type="password" class="form-control" required placeholder="Create Password" name="team_password" id="team_password" />
                                                            <?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Upload Profile Image</label>
                                                            <?php if(!empty($tmember['designation'])){?>
                                                            	<input type="file" class="form-control"  placeholder="Enter Last Name" name="profile_image" id="profile_image" value="" />
                                                            <?php }else{?>	
                                                            	<input type="file" class="form-control"  placeholder="Enter Last Name" name="profile_image" id="profile_image" />
                                                            <?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Whatsapp Mobile No</label>
                                                            <?php if(!empty($tmember['whatsapp_business'])){?>
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="whatsapp_business" id="whatsapp_business" value="<?php echo $tmember['whatsapp_business']?>" />
                                                            <?php }else{?>	
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="whatsapp_business" id="whatsapp_business" />
                                                            <?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Alternate No</label>
                                                            <?php if(!empty($tmember['alternate_no'])){?>
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="alternate_no" id="alternate_no" value="<?php echo $tmember['alternate_no']?>" />
                                                            <?php }else{?>
                                                            	<input type="text" class="form-control"  placeholder="Enter Last Name" name="alternate_no" id="alternate_no" />	
                                                            <?php }?>
                                                            
                                                        </div>
                                                        <div class="col-xl-12 mb-3">
                                                            <label class="form-label">About Member</label>
                                                            <?php if(!empty($tmember['about'])){?>
                                                            <textarea class="form-control" rows="2" name="about" id="about"><?php echo $tmember['about']?></textarea>
                                                            <?php }else{?>	
                                                            	<textarea class="form-control" rows="2" name="about" id="about"></textarea>
                                                            <?php }?>
                                                            
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1">
                                                                Submit
                                                            </button>
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="table-responsive mt-4 mb-4">
                                                    <table id="team_list" class="table table-centered table-nowrap mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Name</th>
                                                                <th scope="col">User ID</th>
                                                                <th scope="col">Username</th>
                                                                <th scope="col">Company Name</th>
                                                                <th scope="col">Designation</th>
                                                                <th scope="col">Email</th>
                                                                <th scope="col" style="width: 200px;">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        	<?php foreach($team as $teamdata):?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2">
                                                                    <a href="<?=site_url('Users/details')?>" class="text-body"><?php echo $teamdata['firstname'].''.$teamdata['lastname']; ?></a>	
                                                                </td>
                                                                <td><?php echo $teamdata['userUID']?></td>
                                                                <td><?php echo $teamdata['username']?></td>
                                                                <td><?php echo $teamdata['company_name']?></td>
                                                                <td><?php echo $teamdata['designation'];?></td>
                                                                <td><?php echo $teamdata['email']?></td>
                                                                <td>
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                        	<?php if($teamdata['enable'] == 0){?>
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil-exclamation-circle font-size-18"></i></a>
                                                                        	<?php }else{?>
                                                                    		<a href="javascript:void(0);" class="px-2 text-primary"><i class="uil-circle font-size-18"></i></a>
                                                                        	<?php }?>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="<?= site_url('Card/team/'.$teamdata['userUID'])?>" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                        	<?php endforeach;?>
                                                        </tbody>
                                                    </table>
                                                </div>
	                                        </div>
	                                        <!-- Card Team -->
	                                        <!-- Card Social -->
	                                        <div class="tab-pane <?= strcmp($activetab, "social") == 0 ? "active" : ""  ?>" id="nav-social" role="tabpanel">
	                                            <form class="repeater custom-validation" action="<?=site_url('Card/social/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr>Add New Social Channel <hr></h4>
                                                    <div class="row">
                                                    	<div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Select Social Icon Pack</label>
                                                            <select class="form-select" name="icon_pack" id="icon_pack">
                                                            	<?php if(!empty($csocial['icon_pack'])){?>
                                                            		<option value="<?php echo $csocial['icon_pack']?>"><?php echo $csocial['icon_pack']?></option>
                                                            	<?php }else{?>
                                                            		<option value="">Choose Icon Pack</option>
                                                                	<option value="Default">Default</option>
                                                            	<?php }?>
                                                            </select>
                                                        </div>
                                                        <?php if(!empty($csocial['channel_name'])){?>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Select Social Channel Name</label>
                                                            <select class="form-select form-control" name="channel_name" id="channel_name">
                                                            	<?php if(!empty($csocial['channel_name'])){?>
                                                            		<option value="<?php echo $csocial['channel_name'];?>"><?php echo $csocial['channel_name'];?></option>
                                                            		<option value="">Choose Social Media or Channel Name</option>
                                                                    <option value="Facebook">Facebook</option>
                                                                    <option value="Instagram">Instagram</option>
                                                                    <option value="Whatsapp">Whatsapp</option>
                                                            	<?php }else{?>
                                                            		<option selected="">Choose Social Media or Channel Name</option>
                                                                    <option value="Facebook">Facebook</option>
                                                                    <option value="Instagram">Instagram</option>
                                                                    <option value="Whatsapp">Whatsapp</option>
                                                            	<?php }?>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label class="form-label">Enter URL</label>
                                                            <?php if(!empty($csocial['channel_url'])){?>
                                                            	<input type="text" class="form-control" required placeholder="Enter First Name" name="channel_url" id="channel_url" value="<?php echo $csocial['channel_url'];?>" />
                                                        	<?php }else{?>
                                                        		<input type="text" class="form-control" required placeholder="Enter First Name" name="channel_url" id="channel_url" />
                                                        	<?php }?>
                                                        </div>
                                                        <div class="col-xl-4 mb-3">
                                                            <label>Choose Icon Visibility</label>
                                                            <select class="form-select form-control" name="icon_visibility" id="icon_visibility">
                                                            	<?php if(!empty($csocial['icon_visibility'])){?>
                                                            		<option value="<?php echo $csocial['icon_visibility']?>"><?php echo $csocial['icon_visibility']?></option>
                                                            		<option value="">Select the Icon Visibility</option>
                                                            		<option value="Visible">Visible</option>
                                                                	<option value="Hide">Hide</option>
                                                            	<?php }else{?>
                                                            		<option value="">Select the Icon Visibility</option>
                                                            		<option value="Visible">Visible</option>
                                                                	<option value="Hide">Hide</option>
                                                            	<?php }?>
                                                            </select>
                                                        </div>
                                                        <?php }else{?>
                                                        <div data-repeater-list="group-a">
                                                            <div data-repeater-item class="row">
                                                                <div class="col-xl-4 mb-3">
                                                                    <label class="form-label">Select Social Channel Name</label>
                                                                    <select class="form-select form-control" name="channel_name" id="channel_name">
                                                                        <option selected="">Choose Social Media or Channel Name</option>
                                                                        <option value="Facebook">Facebook</option>
                                                                        <option value="Instagram">Instagram</option>
                                                                        <option value="Whatsapp">Whatsapp</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-xl-4 mb-3">
                                                                    <label class="form-label">Enter URL</label>
                                                                    <input type="text" class="form-control" required placeholder="Enter First Name" name="channel_url" id="channel_url" />
                                                                </div>
                                                                <div class="col-lg-4">
                                                                    <label>Choose Icon Visibility</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <select class="form-select form-control" name="icon_visibility" id="icon_visibility">
                                                                                <option selected="">Visible</option>
                                                                                <option value="Hide">Hide</option>
                                                                            </select>
                                                                            <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    	<?php }?>
                                                    </div>
                                                    <div>
                                                        <div>
                                                        	<?php if(empty($csocial['channel_name'])){?>
                                                            <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
                                                        	<?php }?>
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="table-responsive mt-4 mb-4">
                                                    <table id="social_list" class="table table-centered table-nowrap mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Company Name</th>
                                                                <th scope="col">Channel Name</th>
                                                                <th scope="col">Channel Status</th>
                                                                <th scope="col" style="width: 200px;">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        	<?php foreach($social as $socialdata):?>
                                                            <tr>
                                                                <td><?php echo $socialdata['company_name']?></td>
                                                                <td><?php echo $socialdata['channel_name']?></td>
                                                                <td><?php if($socialdata['icon_visibility'] != 'Visible'){?>
                                                                    Un Visible
                                                                	<?php }else{?>
                                                            		Visible
                                                                	<?php }?>
                                                                </td>
                                                                <td>
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                            <a href="<?= site_url('Card/social/'.$socialdata['social_id']) ?>" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                        	<?php endforeach;?>
                                                        </tbody>
                                                    </table>
                                                </div>
	                                        </div>
	                                        <!-- Card Social -->
	                                        <!-- Card Product -->
	                                        <div class="tab-pane <?= strcmp($activetab, "product") == 0 ? "active" : ""  ?>" id="nav-product" role="tabpanel">
	                                            <form class="repeater custom-validation" action="<?=site_url('Card/product/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr>Add Bulk Product <hr></h4>
                                                    <div class="row">
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Product List</label>
                                                            <select class="form-select" name="list_view" id="list_view">
                                                                <option selected>Choose Listing View</option>
                                                                <option value="1">2 x 2</option>
                                                                <option value="1">3 x 3</option>
                                                                <option value="1">1 x 1</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Product Category</label>
                                                            <select class="form-select form-control" name="category_name" id="category_name">
                                                                <option selected="">Choose Product Category</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                            </select>
                                                        </div>
                                                        <div data-repeater-list="group-a">
                                                            <div data-repeater-item class="row">
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Name</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <select class="form-select form-control" style="width:25%;" name="position" id="position">
                                                                                <option selected="">1</option>
                                                                                <option value="Referral">2</option>
                                                                                <option value="Referral">3</option>
                                                                                <option value="Referral">4</option>
                                                                                <option value="Referral">5</option>
                                                                            </select>
                                                                            <input type="text" class="form-control" name="pname" id="pname" required/>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Details URL</label>
                                                                    <input type="text" class="form-control" name="pdetails" id="pdetails" />
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Price</label>
                                                                    <input type="text" class="form-control" name="pprice" id="pprice" required/>
                                                                </div>
                                                                
                                                                <div class="col-lg-3">
                                                                    <label>Product Image</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <input type="file" class="form-control" name="product_img" id="product_img" />
                                                                            <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div>
                                                        <div>
                                                            <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="table-responsive mt-4 mb-4">
                                                    <table id="product_list" class="table table-centered table-nowrap mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Product Position</th>
                                                                <th scope="col">Product Image</th>
                                                                <th scope="col">Product URL</th>
                                                                <th scope="col">Product Price</th>
                                                                <th scope="col" style="width: 200px;">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        	<?php foreach($product as $productdata):?>
                                                            <tr>
                                                                <td style="width: 20%;">1</td>
                                                                <td><img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2"></td>
                                                                <td><?php echo $productdata?></td>
                                                                <td><?php echo $productdata?></td>
                                                                <td>
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                        	<?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
	                                        </div>
	                                        <!-- Card Product -->
	                                        <!-- Card Service -->
	                                        <div class="tab-pane <?= strcmp($activetab, "service") == 0 ? "active" : ""  ?>" id="nav-service" role="tabpanel">
	                                            <form class="repeater custom-validation" action="<?=site_url('Card/service/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr>Add Service <hr></h4>
                                                    <div class="row">
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Service Category</label>
                                                            <select class="form-select form-control" name="scategory_name" id="scategory_name">
                                                                <option selected="">Choose Service Category</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Service Hours</label>
                                                            <select class="form-select" name="availablity" id="availablity">
                                                                <option selected>Choose Avalibility</option>
                                                                <option value="Office Timing 9 to 6">Office Timing 9 to 6</option>
                                                                <option value="Always Open">Always Open</option>
                                                                <option value="By Appointment Only">By Appointment Only</option>
                                                            </select>
                                                        </div>
                                                        <div data-repeater-list="group-a">
                                                            <div data-repeater-item class="row">
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Service Name</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <select class="form-select form-control" name="position" style="width:25%;">
                                                                                <option selected="">1</option>
                                                                                <option value="Referral">2</option>
                                                                                <option value="Referral">3</option>
                                                                                <option value="Referral">4</option>
                                                                                <option value="Referral">5</option>
                                                                            </select>
                                                                            <input type="text" class="form-control" name="sname" id="sname"/>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Service Details URL</label>
                                                                    <input type="text" class="form-control" name="sdetails" id="sdetails" required />
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Service Price</label>
                                                                    <input type="text" class="form-control" name="sprice" id="sprice"  required />
                                                                </div>
                                                                <div class="col-lg-3 mb-3">
                                                                    <label>Service Image</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <input type="file" class="form-control"  name="service_img" id="service_img" required  />
                                                                            <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-12 mb-3">
                                                                    <label>About Service</label>
                                                                    <textarea class="form-control" name="about_service" id="about_service" placeholder="Enter short info about services">
                                                                        
                                                                    </textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div>
                                                            <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
                                                            
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="table-responsive mt-4 mb-4">
                                                    <table id="service_list" class="table table-centered table-nowrap mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Service Position</th>
                                                                <th scope="col">Service Image</th>
                                                                <th scope="col">Service URL</th>
                                                                <th scope="col">Service Price</th>
                                                                <th scope="col" style="width: 200px;">Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        	<?php foreach($service as $servicedata):?>
                                                            <tr>
                                                                <td style="width: 20%;">1</td>
                                                                <td><img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2"></td>
                                                                <td><?php echo $servicedata?></td>
                                                                <td><?php echo $servicedata?></td>
                                                                <td>
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                        	<?php endforeach;?>
                                                        </tbody>
                                                    </table>
                                                </div>
	                                        </div>
	                                        <!-- Card Service -->
	                                        <!-- Card Catalogue -->
	                                        <div class="tab-pane <?= strcmp($activetab, "catalogue") == 0 ? "active" : ""  ?>" id="nav-catalogue" role="tabpanel">
	                                            <form class="repeater custom-validation" action="<?=site_url('Card/catalogue/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
                                                    <h4 class="card-title"><hr>Add Catalogue
                                                        <a class="btn btn-success btn-sm waves-effect float-end " data-bs-toggle="modal" data-bs-target="#addcharac"><i class="mdi mdi-plus"></i>  Add Product Characteristcs</a><hr>
                                                    </h4>
                                                    <div class="row">
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Code</label>
                                                            <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Company Name</label>
                                                            <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Product Category</label>
                                                            <select class="form-select form-control" name="cpcategory_name" id="cpcategory_name">
                                                                <option selected="">Choose Product Category</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                                <option value="Referral">Category One</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-3 mb-3">
                                                            <label class="form-label">Select Product Listing</label>
                                                            <select class="form-select" name="clist_view" id="clist_view">
                                                                <option selected>Choose Listing View</option>
                                                                <option value="1">Slider</option>
                                                                <option value="1">List</option>
                                                                <option value="1">2 x 2</option>
                                                                <option value="1">1 x 1</option>
                                                            </select>
                                                        </div>
                                                        <div data-repeater-list="group-a">
                                                            <div data-repeater-item class="row">
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Name</label>
                                                                    <input type="text" class="form-control" name="pname" id="pname" required />
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Details URL</label>
                                                                    <input type="text" class="form-control" name="pdetails" id="pdetails"  required />
                                                                </div>
                                                                <div class="col-xl-3 mb-3">
                                                                    <label class="form-label">Product Price</label>
                                                                    <input type="text" class="form-control" name="pprice" id="pprice"  required />
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <label>Product Image</label>
                                                                    <div class="row">
                                                                        <div class="btn-group" role="group">
                                                                            <input type="file" class="form-control" name="product_img" id="product_img"  required/>
                                                                            <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-6 mb-3">
                                                                    <label class="form-label">Select Product Characteristcs</label>
                                                                    <select class="form-select" name="pcharacteristcs" id="pcharacteristcs" required>
                                                                        <option selected>Choose Listing View</option>
                                                                        <option value="1">Slider</option>
                                                                        <option value="1">List</option>
                                                                        <option value="1">2 x 2</option>
                                                                        <option value="1">1 x 1</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-xl-6 mb-6">
                                                                    <label class="form-label">Characteristcs Value</label>
                                                                    <input type="text" class="form-control" name="pcharavalue" id="pcharavalue" required />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div>
                                                            <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
                                                            <button type="reset" class="btn btn-secondary waves-effect">
                                                                Cancel
                                                            </button>
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div class="modal fade" id="addcharac" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Add Product Characteristcs </h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form>
                                                                    <div class="mb-3">
                                                                        <label for="recipient-name" class="col-form-label">Enter Product Characteristcs Name</label>
                                                                        <input type="text" class="form-control" id="recipient-name">
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="button" class="btn btn-primary">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="table-responsive mt-4 mb-4">
                                                    <table id="catalogue_list" class="table table-centered table-nowrap mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Product Image</th>
                                                                <th scope="col">Product Category</th>
                                                                <th scope="col">Product Name</th>
                                                                <th scope="col">Product URL</th>
                                                                <th scope="col">Action</th>    
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach($catalogue as $cataloguedata):?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2">
                                                                    <a href="<?=site_url('Users/details')?>" class="text-body">Simon Ryles</a>
                                                                </td>
                                                                <td>Product Category Name</td>
                                                                <td>Product Name</td>
                                                                <td>Product Name</td>
                                                                <td>
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                            <?php endforeach;?>
                                                        </tbody>
                                                    </table>
                                                </div>
	                                        </div>
	                                        <!-- Card Catalogue -->
	                                        <!-- Card Gallery -->
	                                        <div class="tab-pane <?= strcmp($activetab, "gallery") == 0 ? "active" : ""  ?>" id="nav-gallery" role="tabpanel">
	                                        	<form class="custom-validation" action="<?=site_url('Card/gallery/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
		                                            <h4 class="card-title"><hr>Upload Gallery<hr></h4>
		                                            <div class="row">
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Company Code</label>
		                                                    <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Company Name</label>
		                                                    <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Upload Gallery Images</label>
		                                                    <input type="file" class="form-control" name="image_name" id="image_name" required />
		                                                </div>
		                                            </div>
		                                            <div>
		                                                <div>
		                                                    <button type="reset" class="btn btn-secondary waves-effect">
		                                                        Cancel
		                                                    </button>
		                                                    <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
		                                                        Submit
		                                                    </button>
		                                                </div>
		                                            </div>
		                                        </form>
	                                            <div class="table-responsive mt-4 mb-4">
		                                            <table id="gallery_list" class="table table-centered table-nowrap mb-0">
		                                                <thead>
		                                                    <tr>
		                                                        <th scope="col">Company Name</th>
		                                                        <th scope="col">Total Image</th>
		                                                        <th scope="col">Date</th>
		                                                        <th scope="col" style="width: 200px;">Action</th>
		                                                    </tr>
		                                                </thead>
		                                                <tbody>
		                                                	<?php foreach($gallery as $gallerydata):?>
		                                                    <tr>
		                                                        <td>
		                                                            <img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2">
		                                                            <a href="<?=site_url('Users/details')?>" class="text-body">Simon Ryles</a>
		                                                        </td>
		                                                        <td><?php echo $gallerydata?></td>
		                                                        <td><?php echo $gallerydata?></td>
		                                                        <td>
		                                                            <ul class="list-inline mb-0">
		                                                                <li class="list-inline-item">
		                                                                    <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
		                                                                </li>
		                                                                <li class="list-inline-item">
		                                                                    <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
		                                                                </li>
		                                                            </ul>
		                                                        </td>
		                                                    </tr>
		                                                	<?php endforeach;?>
		                                                </tbody>
		                                            </table>
		                                        </div>
	                                        </div>
	                                        <!-- Card Gallery -->
	                                        <!-- Card Payments -->
	                                        <div class="tab-pane <?= strcmp($activetab, "payment") == 0 ? "active" : ""  ?>" id="nav-payments" role="tabpanel">
	                                            <form class="repeater custom-validation" action="<?=site_url('Card/payments/'.$customer['company_code'])?>" method="POST" enctype="multipart/form-data">
		                                            <h4 class="card-title"><hr>Add Payments Product <hr></h4>
		                                            <div class="row">
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Company Code</label>
		                                                    <input type="text" class="form-control" name="company_code" id="company_code" value="<?php echo $customer['company_code'] ?>" readonly/>
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Company Name</label>
		                                                    <input type="text" class="form-control" name="company_name" id="company_name"  value="<?php echo $customer['company_name'] ?>"  readonly/>
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Bank Name</label>
		                                                    <input type="text" class="form-control" name="bank_name" id="bank_name" />
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Account Holder Name</label>
		                                                    <input type="text" class="form-control" name="holder_name" id="holder_name" />
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Bank Account Number</label>
		                                                    <input type="text" class="form-control" name="account_no" id="account_no" />
		                                                </div>
		                                                <div class="col-xl-4 mb-3">
		                                                    <label class="form-label">Bank IFSC Code</label>
		                                                    <input type="text" class="form-control" name="IFSC_code" id="IFSC_code" />
		                                                </div>
		                                                <div data-repeater-list="group-a">
		                                                    <div data-repeater-item class="row">
		                                                        <div class="col-xl-3 mb-3">
		                                                            <label class="form-label">Select Payment Channel</label>
		                                                            <select class="form-select form-control" name="payment_channel" id="payment_channel">
		                                                                <option selected="">UPI Payment Channel</option>
		                                                                <option value="Referral">Google Pay</option>
		                                                                <option value="Referral">Phone Pe</option>
		                                                                <option value="Referral">Paytm</option>
		                                                                <option value="Referral">Bahart Pay</option>
		                                                            </select>
		                                                        </div>
		                                                        <div class="col-xl-3 mb-3">
		                                                            <label class="form-label">Enter Registered Number</label>
		                                                            <input type="text" class="form-control" name="registered_no" id="registered_no"  required placeholder="Enter First Name" />
		                                                        </div>
		                                                        <div class="col-xl-3 mb-3">
		                                                            <label class="form-label">Enter UPI ID or URL</label>
		                                                            <input type="text" class="form-control" required placeholder="Enter First Name" name="channel_link" id="channel_link" />
		                                                        </div>
		                                                        <div class="col-lg-3">
		                                                            <label>Upload UPI QR</label>
		                                                            <div class="row">
		                                                                <div class="btn-group" role="group">
		                                                                    <input type="file" class="form-control" name="channel_QR" id="channel_QR" required />
		                                                                    <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
		                                                                </div>
		                                                            </div>
		                                                        </div>
		                                                    </div>
		                                                </div>

		                                            </div>
		                                            <div>
		                                                <div>
		                                                    <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
		                                                    <button type="reset" class="btn btn-secondary waves-effect">
		                                                        Cancel
		                                                    </button>
		                                                    <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
		                                                        Submit
		                                                    </button>
		                                                </div>
		                                            </div>
		                                        </form>
		                                        <div class="table-responsive mt-4 mb-4">
		                                            <table id="payments_list" class="table table-centered table-nowrap mb-0">
		                                                <thead>
		                                                    <tr>
		                                                        <th scope="col">QR</th>
		                                                        <th scope="col">Channel Name</th>
		                                                        <th scope="col">Registerd Number</th>
		                                                        <th scope="col">Bank Details</th>
		                                                        <th scope="col" style="width: 200px;">Action</th>
		                                                    </tr>
		                                                </thead>
		                                                <tbody>
		                                                	<?php foreach($payment as $paymentdata):?>
		                                                    <tr>
		                                                        <td>
		                                                            <img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2">
		                                                            <a href="<?=site_url('Users/details')?>" class="text-body">Simon Ryles</a>
		                                                        </td>
		                                                        <td><?php echo $paymentdata?></td>
		                                                        <td><?php echo $paymentdata?></td>
		                                                        <td><?php echo $paymentdata?></td>
		                                                        <td>
		                                                            <ul class="list-inline mb-0">
		                                                                <li class="list-inline-item">
		                                                                    <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
		                                                                </li>
		                                                                <li class="list-inline-item">
		                                                                    <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
		                                                                </li>
		                                                            </ul>
		                                                        </td>
		                                                    </tr>
		                                                    <?php endforeach;?>
		                                                </tbody>
		                                            </table>
		                                        </div>
	                                        </div>
	                                        <!-- Card Payments -->
	                                    </div>

	                                </div><!-- end card-body -->
	                            </div><!-- end card -->
	                        </div><!-- end col -->
	                    </div>
		            </div>
                </div> <!-- container-fluid -->
            </div>
        </div>
		<?= $this->include('partials/vendor-scripts') ?>
		<?= $this->include('partials/js/main') ?>
		<?= $this->include('partials/js/repeater') ?>
        <?= $this->include('partials/js/datatable') ?>
        <?= $this->include('partials/js/pdfreader.php') ?>
		<script type="text/javascript">

		    $(document).ready(function() {
		        $('#team_list').DataTable();
		        $('#social_list').DataTable();
		        $('#product_list').DataTable();
		        $('#service_list').DataTable();
		        $('#catalogue_list').DataTable();
		        $('#gallery_list').DataTable();
		        $('#payments_list').DataTable();

		        $('#lastname').blur('input', function() {
		            var firstname = $('#firstname').val();
		            var lastname = $('#lastname').val();
		            $('#username').val(firstname +"."+lastname);
		        });
		        // $('#email_address').change(function(){
		        //    var emailval = $('#email_address').val();
		        //    if(emailval != ''){
		        //         $.ajax({
		        //             url: "<?php echo site_url(); ?>Customer/validateemail",
		        //             method: "POST",
		        //             data: {emailval:emailval},
		        //             success: function(response){
		        //             if (response.error){
		        //                 $("#email_address").val('');    
		        //                 $("#email_address").focus();
		        //                 $("#email_address").parent().before("<div style='color:red;'>Email Address Already Exist</div>");
		        //             }else{
		        //             }}
		        //         });
		        //     }
		        // });
		        // $('#mobile_no').change(function(){
		        //    var mobileval = $('#mobile_no').val();
		        //    if(mobileval != ''){
		        //         $.ajax({
		        //             url: "<?php echo site_url(); ?>Customer/validatemobile",
		        //             method: "POST",
		        //             data: {mobileval:mobileval},
		        //             success: function(response){
		        //             if (response.error){
		        //                 $("#mobile_no").val('');    
		        //                 $("#mobile_no").focus();
		        //                 $("#mobile_no").parent().before("<div style='color:red;'>Mobile No Address Already Exist</div>");
		        //             }else{
		        //             }}
		        //         });
		        //     }
		        // });

		        $('.newbtn').bind("click" , function () {
				    $('#pic').click();
				});

				$('.uploadprofile').bind("click" , function () {
				    $('#profile').click();
				});

		    });

		    var _PDF_DOC,
				_CANVAS = document.querySelector('#pdf-preview'),
				_OBJECT_URL;

			function showPDF(pdf_url) {
				PDFJS.getDocument({ url: pdf_url }).then(function(pdf_doc) {
					_PDF_DOC = pdf_doc;

					// Show the first page
					showPage(1);

					// destroy previous object url
			    	URL.revokeObjectURL(_OBJECT_URL);
				}).catch(function(error) {
					// trigger Cancel on error
					document.querySelector("#cancel-pdf").click();
					
					// error reason
					alert(error.message);
				});;
			}

			function showPage(page_no) {
				// fetch the page
				_PDF_DOC.getPage(page_no).then(function(page) {
					// set the scale of viewport
					var scale_required = _CANVAS.width / page.getViewport(1).width;

					// get viewport of the page at required scale
					var viewport = page.getViewport(scale_required);

					// set canvas height
					_CANVAS.height = viewport.height;

					var renderContext = {
						canvasContext: _CANVAS.getContext('2d'),
						viewport: viewport
					};
					
					// render the page contents in the canvas
					page.render(renderContext).then(function() {
						document.querySelector("#pdf-preview").style.display = 'inline-block';
						document.querySelector("#pdf-loader").style.display = 'none';
					});
				});
			}


			/* Show Select File dialog */
			document.querySelector("#upload-dialog").addEventListener('click', function() {
			    document.querySelector("#pdf-file").click();
			});

			/* Selected File has changed */
			document.querySelector("#pdf-file").addEventListener('change', function() {
			    // user selected file
			    var file = this.files[0];

			    // allowed MIME types
			    var mime_types = [ 'application/pdf' ];
			    
			    // Validate whether PDF
			    if(mime_types.indexOf(file.type) == -1) {
			        alert('Error : Incorrect file type');
			        return;
			    }

			    // validate file size
			    if(file.size > 10*1024*1024) {
			        alert('Error : Exceeded size 10MB');
			        return;
			    }

			    // validation is successful

			    // hide upload dialog button
			    document.querySelector("#upload-dialog").style.display = 'none';
			    
			    // set name of the file
			    document.querySelector("#pdf-name").innerText = file.name;
			    document.querySelector("#pdf-name").style.display = 'inline-block';

			    // show cancel and upload buttons now
			    document.querySelector("#cancel-pdf").style.display = 'inline-block';
			    

			    // Show the PDF preview loader
			    document.querySelector("#pdf-loader").style.display = 'inline-block';

			    // object url of PDF 
			    _OBJECT_URL = URL.createObjectURL(file)

			    // send the object url of the pdf to the PDF preview function
				showPDF(_OBJECT_URL);
			});

			/* Reset file input */
			document.querySelector("#cancel-pdf").addEventListener('click', function() {
			    // show upload dialog button
			    document.querySelector("#upload-dialog").style.display = 'inline-block';

			    // reset to no selection
			    document.querySelector("#pdf-file").value = '';

			    // hide elements that are not required
			    document.querySelector("#pdf-name").style.display = 'none';
			    document.querySelector("#pdf-preview").style.display = 'none';
			    document.querySelector("#pdf-loader").style.display = 'none';
			    document.querySelector("#cancel-pdf").style.display = 'none';
			});


		    function uploadcompanylogo(input) {
			    if (input.files && input.files[0]) {
			        var reader = new FileReader();

			        reader.onload = function (e) {

			            $('#blah')
			                .attr('src', e.target.result);
			        };
			        reader.readAsDataURL(input.files[0]);
			    }
			}
			function uploadprofile(input) {
			    if (input.files && input.files[0]) {
			        var reader = new FileReader();
			        reader.onload = function (e) {
			            $('#profilehere')
			                .attr('src', e.target.result);
			        };
			        reader.readAsDataURL(input.files[0]);
			    }
			}
		</script>
</body>

</html>

