<!-- apexcharts -->
<script src="<?=base_url('')?>/public/assets/libs/apexcharts/apexcharts.min.js"></script>

<script src="<?=base_url('')?>/public/assets/js/pages/dashboard.init.js"></script>