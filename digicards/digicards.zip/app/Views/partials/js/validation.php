
<script src="<?=site_url('public/assets/libs/parsleyjs/parsley.min.js')?>"></script>

<script src="<?=site_url('public/assets/js/pages/form-validation.init.js')?>"></script>