<script src="<?=site_url('public/assets/js/pages/form-advanced.init.js')?>"></script>
<script src="<?=site_url('public/assets/libs/select2/js/select2.min.js')?>"></script>