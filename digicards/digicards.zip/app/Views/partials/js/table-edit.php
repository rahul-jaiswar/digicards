<!-- Table Editable plugin -->
<script src="<?=site_url('public/assets/libs/table-edits/build/table-edits.min.js')?>"></script>
<script src="<?=site_url('public/assets/js/pages/table-editable.int.js')?>"></script>
