<script src="<?=site_url('public/assets/libs/jquery-steps/build/jquery.steps.min.js')?>"></script>
<!-- form wizard init -->
<script src="<?=site_url('public/assets/js/pages/form-wizard.init.js')?>"></script>