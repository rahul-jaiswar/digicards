<!-- JAVASCRIPT -->
<script src="<?=base_url('')?>/public/assets/libs/jquery/jquery.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/node-waves/waves.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/jquery.counterup/jquery.counterup.min.js"></script>
<!-- <script type="text/javascript">
var configuration = {
    widgetId: "326c75744c53393933353030",
    tokenAuth: "387140TGm4h5i3063a32190P1",
    success: (data) => {
        // get verified token in response
        console.log('success response', data);
    },
    failure: (error) => {
        // handle error
        console.log('failure reason', error);
    }
};
</script>
<script type="text/javascript" onload="initSendOTP(configuration)" src="https://control.msg91.com/app/assets/otp-provider/otp-provider.js"> </script> -->
