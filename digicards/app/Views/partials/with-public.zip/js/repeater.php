<script src="<?php echo site_url('public/assets/libs/jquery.repeater/jquery.repeater.min.js')?>"></script>
<script src="<?php echo site_url('public/assets/js/pages/form-repeater.int.js')?>"></script>