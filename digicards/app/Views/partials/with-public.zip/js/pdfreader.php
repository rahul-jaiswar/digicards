<!-- apexcharts -->
<script src="<?=base_url('')?>/public/assets/js/pdf.js"></script>
<script src="<?=base_url('')?>/public/assets/js/pdf.worker.js"></script>