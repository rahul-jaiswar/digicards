<!-- Responsive Table js -->
<script src="<?=site_url('assets/libs/admin-resources/rwd-table/rwd-table.min.js')?>"></script>
<script src="<?=site_url('assets/js/pages/table-responsive.init.js')?>"></script>