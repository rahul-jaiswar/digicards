<script src="<?=site_url('assets/js/pages/form-advanced.init.js')?>"></script>
<script src="<?=site_url('assets/libs/select2/js/select2.min.js')?>"></script>