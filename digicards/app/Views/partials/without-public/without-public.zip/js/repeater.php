<script src="<?php echo site_url('assets/libs/jquery.repeater/jquery.repeater.min.js')?>"></script>
<script src="<?php echo site_url('assets/js/pages/form-repeater.int.js')?>"></script>