<script src="<?=site_url('assets/libs/spectrum-colorpicker2/spectrum.min.js')?>"></script>
<script src="<?=site_url('assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')?>"></script>