<!-- apexcharts -->
<script src="<?=base_url('')?>/assets/js/pdf.js"></script>
<script src="<?=base_url('')?>/assets/js/pdf.worker.js"></script>