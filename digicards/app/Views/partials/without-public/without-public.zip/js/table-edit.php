<!-- Table Editable plugin -->
<script src="<?=site_url('assets/libs/table-edits/build/table-edits.min.js')?>"></script>
<script src="<?=site_url('assets/js/pages/table-editable.int.js')?>"></script>
