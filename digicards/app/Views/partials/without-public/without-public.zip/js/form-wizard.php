<script src="<?=site_url('assets/libs/jquery-steps/build/jquery.steps.min.js')?>"></script>
<!-- form wizard init -->
<script src="<?=site_url('assets/js/pages/form-wizard.init.js')?>"></script>