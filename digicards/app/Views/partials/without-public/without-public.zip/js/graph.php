<!-- apexcharts -->
<script src="<?=base_url('')?>/assets/libs/apexcharts/apexcharts.min.js"></script>

<script src="<?=base_url('')?>/assets/js/pages/dashboard.init.js"></script>