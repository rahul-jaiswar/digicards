
<script src="<?=site_url('assets/libs/parsleyjs/parsley.min.js')?>"></script>

<script src="<?=site_url('assets/js/pages/form-validation.init.js')?>"></script>