<link href="<?=site_url('assets/libs/spectrum-colorpicker2/spectrum.min.css')?>" rel="stylesheet" type="text/css">
<link href="<?=site_url('assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css')?>" rel="stylesheet" />
