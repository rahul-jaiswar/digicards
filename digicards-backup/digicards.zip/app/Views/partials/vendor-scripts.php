<!-- JAVASCRIPT -->
<script src="<?=base_url('')?>/public/assets/libs/jquery/jquery.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/node-waves/waves.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?=base_url('')?>/public/assets/libs/jquery.counterup/jquery.counterup.min.js"></script>