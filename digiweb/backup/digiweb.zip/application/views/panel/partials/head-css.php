<!-- Bootstrap Css -->
<link href="<?php echo site_url('assets/admin/css/bootstrap.min.css')?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo site_url('assets/admin/css/icons.min.css')?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo site_url('assets/admin/css/app.min.css')?>" id="app-style" rel="stylesheet" type="text/css" />


