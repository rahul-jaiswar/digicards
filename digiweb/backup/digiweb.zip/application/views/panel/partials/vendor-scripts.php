<!-- JAVASCRIPT -->
<script src="<?php echo site_url('assets/admin/libs/jquery/jquery.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/metismenu/metisMenu.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/simplebar/simplebar.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/node-waves/waves.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/waypoints/lib/jquery.waypoints.min.js')?>"></script>
<script src="<?php echo site_url('assets/admin/libs/jquery.counterup/jquery.counterup.min.js')?>"></script>