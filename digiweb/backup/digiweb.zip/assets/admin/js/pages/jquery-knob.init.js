$(function() {
    $(".knob").knob();
});