<!doctype html>
<html lang="en">
<head>
    <?php $this->load->view('theme/default/head-css') ?>
</head>

<body class="">

    <!-- loader -->
    <div id="loader">
        <img src="<?php echo site_url('assets/theme/img/loading-icon.png')?>" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->
    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="section mt-2 text-center">
            <img src="<?php echo site_url('assets/web/images/black-logo.png')?>" alt="Logo" class="mega-white-logo" style="height: 100px;"/>
        </div>
        <div class="section mb-5 p-2">
            <form action="#">
                <div class="card">
                    <div class="card-body pb-1">
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label" for="email1">Mobile No</label>
                                <input type="email" class="form-control" id="email1" placeholder="Your e-mail">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-button-group  transparent">
                    <button type="submit" class="btn btn-primary btn-block btn-lg">Click to Know Gift of Your Santa</button>
                </div>  
            </form>
        </div>

    </div>
    <!-- * App Capsule -->
    <?php $this->load->view('theme/default/vendor-scripts') ?>
</body>

</html>