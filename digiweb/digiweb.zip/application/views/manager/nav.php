<!-- App Bottom Menu -->
<div class="appBottomMenu">
    <a href="<?= site_url($this->uri->segment('1').'/home') ?>" class="item">
        <div class="col">
            <ion-icon name="home-outline"></ion-icon>
            <strong>Info</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/team') ?>" class="item">
        <div class="col">
            <ion-icon name="people-outline"></ion-icon>
            <strong>Team</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/service') ?>" class="item">
        <div class="col">
            <ion-icon name="logo-facebook"></ion-icon>
            <strong>Social</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/catalogue') ?>" class="item">
        <div class="col">
            <ion-icon name="copy-outline"></ion-icon>
            <strong>Product</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/gallery') ?>" class="item">
        <div class="col">
            <ion-icon name="reader-outline"></ion-icon>
            <strong>Service</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="reader-outline"></ion-icon>
            <strong>Catalogue</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="images-outline"></ion-icon>
            <strong>Gallery</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="card-outline"></ion-icon>
            <strong>Payments</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="card-outline"></ion-icon>
            <strong>Payments</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="card-outline"></ion-icon>
            <strong>Payments</strong>
        </div>
    </a>
    <a href="<?= site_url($this->uri->segment('1').'/payments') ?>" class="item">
        <div class="col">
            <ion-icon name="card-outline"></ion-icon>
            <strong>Payments</strong>
        </div>
    </a>
</div>
<!-- * App Bottom Menu -->