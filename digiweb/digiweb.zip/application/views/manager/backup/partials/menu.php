<?php $this->load->view('manager/partials/top-nav') ?>
<?php $this->load->view('manager/partials/sidebar') ?>
