<!doctype html>
<html lang="en">
<head>
    <?php $this->load->view('partials/head-css') ?>
    <style type="text/css">
    </style>
</head>
<body class="" style="position: relative;width: 360px;height: 640px;margin: auto;">
    
    <?php $this->load->view('manager/nav')?>
    <?php $this->load->view('partials/vendor-scripts') ?>
</body>
</html> 