<div class="appFooter" style="position: relative;bottom: 0em;">
    <div class="footer-title">
        Copyright © Tap-Savvy 2023. All Rights Reserved.
    </div>www.tap-savvy.com
</div>