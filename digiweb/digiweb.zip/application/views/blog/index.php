<?php $this->load->view('default/header');?>
	 <body>      
		<?php $this->load->view('default/nav-black');?>
	  	<!--Breadcrumb Area-->
		  <section class="breadcrumb-area " data-background="images/banner/9.jpg">
		    <div class="text-block">
		      <div class="container">
		        <div class="row">
		          <div class="col-lg-12 v-center">
		            <div class="bread-inner">
		              <div class="bread-menu">
		                <ul>
		                  <li><a href="<?php site_url('')?>">Tap Savvy</a></li>
		                </ul>
		              </div>
		              <div class="bread-title">
		                <h2>Knowledge Center</h2>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div>
		    </div>
		  </section>
	  	<!--End Breadcrumb Area-->
		  <!--Start Blog Grid-->
		  <section class="blog-page pad-tb pt40">
		    <div class="container">
					<div class="row">
						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-1.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post dg-bg2">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Nodejs</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 23, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Everything You Need To Know About Nodejs!</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-2.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post bg-gradient12">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Laravel</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 24, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Exploring the Key Features of Laravel 7 Framework</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-3.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post dg-bg2">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Mobile Application</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 25, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Best Technology for Mobile Application Development</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-1.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post dg-bg2">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Nodejs</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 23, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Everything You Need To Know About Nodejs!</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-2.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post bg-gradient13">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Laravel</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 24, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Exploring the Key Features of Laravel 7 Framework</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mt60">
							<div class="single-blog-post- shdo">
								<div class="single-blog-img-">
									<a href="#"><img src="<?php echo site_url('assets/web/images/blog/blog-dg-3.jpg')?>" alt="girl" class="img-fluid"></a>
									<div class="entry-blog-post dg-bg2">
										<span class="bypost-"><a href="#"><i class="fas fa-tag"></i> Mobile Application</a></span>
										<span class="posted-on-">
											<a href="#"><i class="fas fa-clock"></i> Sep 25, 2020</a>
										</span>
									</div>
								</div>
								<div class="blog-content-tt">
									<div class="single-blog-info-">
										<h4><a href="#">Best Technology for Mobile Application Development</a></h4>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
									</div>
									<div class="post-social">
										<div class="ss-inline-share-wrapper ss-hover-animation-fade ss-inline-total-counter-left ss-left-inline-content ss-small-icons ss-with-spacing ss-circle-icons ss-without-labels">
											<div class="ss-inline-share-content">
												<div class="ss-social-icons-container">
													<a href="javascript:void(0)">Shares</a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-twitter"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-linkedin"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fas fa-envelope"></i></a>
													<a href="javascript:void(0)" target="blank"><i class="fab fa-facebook-messenger"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
		    </div>
		  </section>
     <?php $this->load->view('default/footer.php');?>
   <?php $this->load->view('default/off-canvas.php');?>
<?php $this->load->view('default/script.php');?>