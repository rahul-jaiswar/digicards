<!--Start Preloader -->
<div class="onloadpage" id="page_loader">
 <div class="pre-content">
    <div class="logo-pre"><h6>Tap Savvy</h6></div>
    <div class="pre-text-">New Generation Digital Card</div>
 </div>
</div>
<!--End Preloader -->