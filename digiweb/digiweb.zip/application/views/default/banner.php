<!--Start Hero-->
<section class="hero-card-web" style="background: url('https://www.corporatecomplianceinsights.com/wp-content/uploads/2020/05/online-banking.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;">
 <div class="text-block">
    <div class="container">
       <div class="row justify-content-between">
         <div class="col-lg-5">
             
          </div>
          <div class="col-lg-6 niwax" data-rellax-speed="-3">
             <div class="header-heading">
                <span class="mb15 d-block">Tap-Savvy<span class="badge bg-primary" style="margin-left:20px;">   New Generation Digital Visiting Card</span></span>
                <h3 class="wow fadeIn cd-headline clip" data-wow-delay=".2s">Welcome to Gen Z way Of Networking as a
                   <span class="cd-words-wrapper"> <b class="is-visible">Individual</b> <b>Brand</b> <b>Professional</b> <b>Graphic Design</b> <b>Content Creator</b>
                   <b>Corporate Business</b> <b>Institution</b> <b>Freelancer</b></span>  
                </h3>
                <p class="wow fadeIn" data-wow-delay=".6s">In a single blink of an eye, networking! With this card, there will be no FOMO.</p>
                <a href="register.php" class="niwax-btn2 wow zoomInDown mt10" data-wow-delay=".6s">Create Your Card<i class="fas fa-chevron-right fa-icon"></i></a>
             </div>
          </div>
          
       </div>
    </div>
 </div>
</section>
<!--End Hero-->