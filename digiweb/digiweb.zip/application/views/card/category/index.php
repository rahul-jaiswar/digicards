<?php $this->load->view('card/category/'.$details->temp_cat.'',$details)?>
<!--?php $this->load->view('card/category/individual')?-->
<!--?php $this->load->view('card/category/individual')?-->

