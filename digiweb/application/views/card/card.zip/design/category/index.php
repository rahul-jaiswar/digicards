<?php $this->load->view('card/design/category/'.$details->temp_cat.'',$details)?>
<!--?php $this->load->view('card/design/category/individual')?-->
<!--?php $this->load->view('card/design/category/individual')?-->

