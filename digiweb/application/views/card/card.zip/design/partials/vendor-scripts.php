<!-- ========= JS Files =========  -->
<!-- Bootstrap -->
<script src="<?=base_url('')?>assets/card/js/lib/bootstrap.bundle.min.js"></script>
<!-- Ionicons -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<!-- Splide -->
<script src="<?=base_url('')?>assets/card/js/plugins/splide/splide.min.js"></script>
<!-- Base Js File -->
<script src="<?=base_url('')?>/assets/card/js/base.js"></script>
<script>
    // Add to Home with 2 seconds delay.
    AddtoHome("2000", "once");
</script>