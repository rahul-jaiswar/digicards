<!doctype html>
<html lang="en">
<head>
    <?php $this->load->view('panel/partials/head-css') ?>
</head>
    <?php $this->load->view('panel/partials/body') ?>
        <!-- Begin page -->
        <div id="layout-wrapper">
            <?php $this->load->view('panel/partials/menu') ?>
            <div class="main-content">
                <div class="container-fluid">
                    <?php if ($this->session->flashdata('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $this->session->flashdata('success'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <?php $this->session->unset_userdata ( 'success' ); ?>
                      </div>
                      <?php elseif ($this->session->flashdata('error')): ?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $this->session->flashdata('error'); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                      <?php $this->session->unset_userdata ( 'error' ); ?>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <form class="repeater custom-validation" action="<?=site_url('Customer/team',$this->uri->segment('3'))?>" method="POST" enctype="multipart/form-data">
                                                <h4 class="card-title">Add Service <hr></h4>
                                                <div class="row">
                                                    <div class="col-xl-3 mb-3">
                                                        <label class="form-label">Company Code</label>
                                                        <input type="text" class="form-control" name="userUID" id="userUID"readonly />
                                                    </div>
                                                    <div class="col-xl-3 mb-3">
                                                        <label class="form-label">Company Name</label>
                                                        <input type="text" class="form-control" name="userUID" id="userUID" readonly />
                                                    </div>
                                                    <div class="col-xl-3 mb-3">
                                                        <label class="form-label">Select Service Category</label>
                                                        <select class="form-select form-control" name="gender" id="basicpill-firstname-input">
                                                            <option selected="">Choose Service Category</option>
                                                            <option value="Referral">Category One</option>
                                                            <option value="Referral">Category One</option>
                                                            <option value="Referral">Category One</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-xl-3 mb-3">
                                                        <label class="form-label">Select Service Hours</label>
                                                        <select class="form-select" name="userType" id="userType">
                                                            <option selected>Choose Avalibility</option>
                                                            <option value="1">Office Timing 9 to 6</option>
                                                            <option value="1">Always Open</option>
                                                            <option value="1">By Appointment Only</option>
                                                        </select>
                                                    </div>
                                                    <div data-repeater-list="group-a">
                                                        <div data-repeater-item class="row">

                                                            <div class="col-xl-3 mb-3">
                                                                <label class="form-label">Service Name</label>
                                                                <div class="row">
                                                                    <div class="btn-group" role="group">
                                                                        <select class="form-select form-control" style="width:25%;">
                                                                            <option selected="">1</option>
                                                                            <option value="Referral">2</option>
                                                                            <option value="Referral">3</option>
                                                                            <option value="Referral">4</option>
                                                                            <option value="Referral">5</option>
                                                                        </select>
                                                                        <input type="text" class="form-control" required placeholder="" name="firstname" id="firstname" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-3 mb-3">
                                                                <label class="form-label">Service Details URL</label>
                                                                <input type="text" class="form-control" required placeholder="" name="firstname" id="firstname" />
                                                            </div>
                                                            <div class="col-xl-3 mb-3">
                                                                <label class="form-label">Service Price</label>
                                                                <input type="text" class="form-control" required placeholder="" name="firstname" id="firstname" />
                                                            </div>
                                                            <div class="col-lg-3 mb-3">
                                                                <label>Service Image</label>
                                                                <div class="row">
                                                                    <div class="btn-group" role="group">
                                                                        <input type="file" class="form-control" required placeholder="" name="firstname" id="firstname" />
                                                                        <button data-repeater-delete type="button" class="btn btn-outline-danger waves-effect waves-light"><i class="uil uil-trash-alt "></i></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-12 mb-3">
                                                                <label>About Service</label>
                                                                <textarea class="form-control" placeholder="Enter short info about services">
                                                                    
                                                                </textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div>
                                                        <input data-repeater-create type="button" class="btn btn-success mt-3 mt-lg-0" value="Add" />
                                                        
                                                        <button type="reset" class="btn btn-secondary waves-effect">
                                                            Cancel
                                                        </button>
                                                        <button type="submit" class="btn btn-primary waves-effect waves-light me-1 ">
                                                            Submit
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive mb-4">
                                                <table class="table table-centered table-nowrap mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">Service Position</th>
                                                            <th scope="col">Service Image</th>
                                                            <th scope="col">Service URL</th>
                                                            <th scope="col">Service Price</th>
                                                            <th scope="col" style="width: 200px;">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td style="width: 20%;">1</td>
                                                            <td><img src="<?=site_url('public/assets/images/users/avatar-2.jpg')?>" alt="" class="avatar-xs rounded-circle me-2"></td>
                                                            <td>Full Stack Developer</td>
                                                            <td>150</td>
                                                            <td>
                                                                <ul class="list-inline mb-0">
                                                                    <li class="list-inline-item">
                                                                        <a href="javascript:void(0);" class="px-2 text-primary"><i class="uil uil-pen font-size-18"></i></a>
                                                                    </li>
                                                                    <li class="list-inline-item">
                                                                        <a href="javascript:void(0);" class="px-2 text-danger"><i class="uil uil-trash-alt font-size-18"></i></a>
                                                                    </li>
                                                                </ul>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="row mt-4">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <p class="mb-sm-0">Showing 1 to 10 of 12 entries</p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="float-sm-end">
                                                        <ul class="pagination mb-sm-0">
                                                            <li class="page-item disabled">
                                                                <a href="#" class="page-link"><i class="mdi mdi-chevron-left"></i></a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link">1</a>
                                                            </li>
                                                            <li class="page-item active">
                                                                <a href="#" class="page-link">2</a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link">3</a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link"><i class="mdi mdi-chevron-right"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End row -->
                </div> 
            </div>
        </div>
        <!-- END layout-wrapper -->

        <?php $this->load->view('panel/partials/vendor-scripts') ?>
        <script src="<?php echo site_url('assets/admin/js/pages/dashboard.init.js')?>"></script>
        <script src="<?php echo site_url('assets/admin/js/app.js')?>"></script>
        <script src="<?php echo site_url('assets/admin/libs/jquery.repeater/jquery.repeater.min.js')?>"></script>
        <script src="<?php echo site_url('assets/admin/js/pages/form-repeater.int.js')?>"></script>

    </body>

</html>

