<!-- App Bottom Menu -->
<div class="appBottomMenu">
    <a href="index.html" class="item">
        <div class="col">
            <ion-icon name="person-circle-outline"></ion-icon>
            <strong>Profile</strong>
        </div>
    </a>
    <a href="app-pages.html" class="item">
        <div class="col">
            <ion-icon name="share-social-outline"></ion-icon>
            <strong>Social</strong>
        </div>
    </a>
    <a href="<?php echo site_url('Template/aboutus')?>" class="item">
        <div class="col">
            <ion-icon name="images-outline"></ion-icon>
            <strong>Gallery</strong>
        </div>
    </a>
</div>
<!-- * App Bottom Menu -->