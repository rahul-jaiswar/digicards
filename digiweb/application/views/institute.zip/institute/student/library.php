<!doctype html>
<html lang="en">
<head>
    <?php $this->load->view('theme/default/head-css') ?>
</head>
<body class="">
        <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            Library
        </div>
        
    </div>
    <!-- * App Header -->

    
    <!-- * Dialog Basic -->
        <div id="appCapsule" class="full-height">

        <div class="section mt-2">
            <div class="card">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Book Name</th>
                                <th scope="col">Issue Date</th>
                                <th scope="col" class="text-end">Return Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                            <tr>
                                <th scope="row">Book Name</th>
                                <td>12-12-2020</td>
                                <td class="text-end text-primary">12-01-2023</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- * App Capsule -->
    <?php $this->load->view('institute/nav/student') ?>
    <?php $this->load->view('institute/default/vendor-scripts') ?>
</body>

</html>